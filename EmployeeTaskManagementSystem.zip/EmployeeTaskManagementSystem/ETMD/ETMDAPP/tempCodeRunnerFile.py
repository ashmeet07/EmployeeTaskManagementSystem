from django.db.models import Count
# from django.core.mail import send_mail
# from django.conf import settings
# from .models import Task, FinishedTask